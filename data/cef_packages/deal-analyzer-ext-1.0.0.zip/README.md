# Wholesale Deal Analyzer — Chrome Extension

Version: 1.0.0
Built by: Wholesale Omniverse

## Install (Developer Mode)

1. Unzip this package
2. Open Chrome → `chrome://extensions`
3. Enable **Developer mode** (top right toggle)
4. Click **Load unpacked** → select the `src/` folder
5. Navigate to any Zillow or Redfin listing — the overlay appears automatically

## What It Shows

| Field | Description |
|-------|-------------|
| List Price | Current asking price from the listing |
| Est. ARV | List price × 1.10 (conservative 10% upside estimate) |
| Est. Repairs | List price × 5% |
| **MAO** | ARV × 70% − repairs − $10,000 assignment fee |
| Spread | List price vs MAO (positive = deal, negative = pass) |

## Pricing

- $47/mo individual
- $97/mo team (up to 5 users)

Contact: WholesaleOmniverse@gmail.com | 207-385-4041
